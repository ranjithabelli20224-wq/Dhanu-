DANU FF — Android Studio source project

This is source code, not a compiled APK.
Features: password gate (demo password: Danu FF 09), Vivo Y40 / 8 GB profile,
starter sensitivity values, custom HUD guidance, and aim-practice guidance.
It does not interact with or modify Free Fire and contains no cheats.

Build an APK:
1. Install Android Studio on a computer.
2. Open this folder as an existing project.
3. Let Gradle sync complete.
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the generated APK location.

Security note: the demo password is stored in the app source and is not secure for
protecting sensitive data. Change it before any real distribution.
