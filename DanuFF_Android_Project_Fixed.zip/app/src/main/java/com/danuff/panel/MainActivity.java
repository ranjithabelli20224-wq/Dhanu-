package com.danuff.panel;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    private static final String PASS = "Danu FF 09";
    private LinearLayout root;
    private int blue = Color.rgb(57,184,255);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().getDecorView().setSystemUiVisibility(0);
        showLogin();
    }

    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size);
        t.setTextColor(color); if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setGravity(Gravity.CENTER); t.setPadding(12,12,12,12); return t;
    }
    private void shell() {
        root = new LinearLayout(this); root.setOrientation(1);
        root.setGravity(Gravity.CENTER_HORIZONTAL); root.setPadding(22,28,22,22);
        root.setBackgroundColor(Color.rgb(5,17,38));
        setContentView(root);
    }
    private Button button(String label) {
        Button b = new Button(this); b.setText(label); b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(15,91,151)));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,9,0,9);
        root.addView(b,p); return b;
    }
    private void showLogin() {
        shell();
        root.addView(text("🐉",56,blue,true));
        root.addView(text("DANU FF",30,Color.WHITE,true));
        root.addView(text("FREE FIRE PRACTICE PANEL",14,blue,true));
        EditText input = new EditText(this); input.setSingleLine(true);
        input.setHint("Enter password"); input.setTextColor(Color.WHITE); input.setHintTextColor(0xFF9AB4CC);
        input.setInputType( android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD );
        root.addView(input,new LinearLayout.LayoutParams(-1,-2));
        Button login = button("UNLOCK");
        login.setOnClickListener(v -> {
            if (PASS.equals(input.getText().toString())) showHome();
            else Toast.makeText(this,"Wrong password",Toast.LENGTH_SHORT).show();
        });
        root.addView(text("Demo password: Danu FF 09",12,0xFF9AB4CC,false));
    }
    private void showHome() {
        shell();
        root.addView(text("DANU FF",30,Color.WHITE,true));
        root.addView(text("Vivo Y40 • 8 GB RAM",15,blue,true));
        root.addView(text("HEADSHOT PRACTICE SETTINGS",17,Color.WHITE,true));
        String[] rows = {"General        180","Red Dot        170","2x Scope       155","4x Scope       145","Sniper          95","Free Look      130"};
        for (String s: rows) {
            TextView t=text(s,18,Color.WHITE,true); t.setBackgroundColor(0xFF102B4A);
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,5,0,5); root.addView(t,p);
        }
        root.addView(text("These are starting suggestions. Adjust in-game to your comfort.",12,0xFF9AB4CC,false));
        button("CUSTOM HUD GUIDE").setOnClickListener(v -> new AlertDialog.Builder(this)
            .setTitle("Custom HUD guide")
            .setMessage("Open Free Fire Settings > Controls > Custom HUD. Move and resize buttons to suit your fingers, then test in Training Mode.")
            .setPositiveButton("OK",null).show());
        button("AIM PRACTICE").setOnClickListener(v -> new AlertDialog.Builder(this)
            .setTitle("Aim practice")
            .setMessage("Use Training Mode to practise drag shots and tracking. This app does not modify Free Fire or provide auto-aim, aim-bot, auto-headshot, fly hacks, or other cheats.")
            .setPositiveButton("OK",null).show());
        button("LOCK APP").setOnClickListener(v -> showLogin());
    }
}